def ftoc(num)
  (num - 32)*(5.0/9.0)
end

def ctof(num)
  (num * (9.0/5.0)) + 32
end
