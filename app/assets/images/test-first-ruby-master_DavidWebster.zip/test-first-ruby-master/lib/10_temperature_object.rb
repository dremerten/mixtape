class Temperature
attr_accessor :fahrenheit, :celsius, :options

  def initialize(options={})
    @options = options
    @fahrenheit = options[:f]
    @celsius = options[:c]
  end

  def in_fahrenheit
    @options.has_key?(:c) ? (@celsius * (9.0/5.0)) + 32 : @fahrenheit
  end

  def in_celsius
    @options.has_key?(:f) ? (@fahrenheit - 32)*(5.0/9.0) : @celsius
  end

  def self.from_fahrenheit(n)
    self.new(:f => n)
  end

  def self.from_celsius(n)
    self.new(:c => n)
  end
end

class Celsius < Temperature
  def initialize(temp)
    @celsius = temp
    @options = { :c => temp }
  end
end

class Fahrenheit < Temperature

  def initialize(temp)
    @fahrenheit = temp
    @options = {:f => temp}
  end
end
