$vowels = "aeiou"

def translate(str)
  str.split.map { |s| $vowels.include?(s[0].downcase) ? "#{s}ay" : consonant(s) }.join(" ")
end

def consonant(s)
  0.upto(s.length - 1) do |n|
      if $vowels.include?(s[n]) && s[n-1..n].downcase != "qu"
        if s == s.capitalize
          return "#{s[n..-1]}#{s[0..n-1]}ay".capitalize
        else
          return "#{s[n..-1]}#{s[0..n-1]}ay"
        end
      end
    end
end
