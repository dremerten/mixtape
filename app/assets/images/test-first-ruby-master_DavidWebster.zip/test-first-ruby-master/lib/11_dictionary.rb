class Dictionary
attr_accessor :entries
  def initialize(entries={})
    @entries = entries
  end

  def add(n)
    if n.is_a? Hash
      n.each { |k,v| @entries[k] = v }
    else
      @entries[n] = nil
    end
  end

  def include?(n)
    @entries.include?(n) ? true : false
  end

  def find(n)
    new_hash = Hash.new
    @entries.each { |k,v| k.include?(n) ? new_hash[k] = v : nil}
    new_hash
  end

  def keywords
    @entries.keys.sort!
  end

  def printable
    printer = @entries.sort.map { |k,v| "[#{k}] \"#{v}\"" }
    printer.join("\n")
  end

end
