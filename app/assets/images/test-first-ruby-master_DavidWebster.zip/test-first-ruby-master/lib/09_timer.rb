class Timer

attr_accessor :seconds

  def padded(n)
    n < 10 ? "0#{n}" : n.to_s
  end

  def initialize(seconds=0)
    @seconds = seconds
  end

  def time_string
    @@minutes = (@seconds / 60) % 60
    @@hours = (@seconds / 60 / 60) % 60
    "#{padded(@@hours)}:#{padded(@@minutes)}:#{padded(@seconds % 60)}"
  end
end
