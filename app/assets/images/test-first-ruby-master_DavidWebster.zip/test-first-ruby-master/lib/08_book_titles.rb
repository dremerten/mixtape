class Book
attr_accessor :title

  @@stop_words = %w{the a an and in of}

  def initialize(title=nil)
    @title = title
  end

  def title
    i = 0
    @title.split.each do |word|
    !@@stop_words.include?(word) || i == 0 ? word.capitalize! : word
    i += 1
    end.join(" ")
  end
end
