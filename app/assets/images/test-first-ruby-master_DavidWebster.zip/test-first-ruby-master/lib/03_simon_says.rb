def echo(string)
  string
end

def shout(string)
  string.upcase
end

def repeat(string, d=2)
  "#{string} " * (d-1) + string
end

def start_of_word(string, d)
  result = ""
  0.upto(d-1) { |n| result += string[n]}
  result
end

def first_word(string)
  string.split.first
end

def titleize(string)
  little_words = %w{a an the and but or for nor on at to from by over if}
  i = 0
  string.split.each do |word|
    !little_words.include?(word) || i == 0 ? word.capitalize! : word
    i += 1
  end.join(" ")
end
