class Array
  def sum
    result = 0
    self.each {|n| result += n }
    result
  end

  def square
    result = []
    self.each {|n| result << n**2 }
    result
  end

  def square!
    0.upto(self.length - 1) {|n| self[n] = self[n]**2 }
  end
end
