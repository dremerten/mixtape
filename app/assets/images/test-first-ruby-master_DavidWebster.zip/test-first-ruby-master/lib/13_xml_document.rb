class XmlDocument

  def initialize(indent = false)
    @indent = indent
    @idx = 0
    @array = []
  end

  def method_missing(m, *args, &block)
    @@space = "  " * @idx
    if @indent == false
      if args[0].is_a? Hash
        s = args[0].map {|k,v| "#{k.to_s}=\"#{v}\"/>"}
        "<#{m} #{s[0]}"
      elsif block_given?
        "<#{m}>#{block.call}</#{m}>"
      else
        "<#{m}/>"
      end
    else
      if args[0].is_a? Hash
        s = args[0].map {|k,v| "#{k.to_s}=\"#{v}\"/>"}
        @array << @@space + "<#{m} #{s[0]}\n"
      else
        @array << @@space + "<#{m}>\n"
        @idx +=1
        yield
      end
      @array.join + @array.map { |tag| tag.gsub('<', '</') } [0..-2].reverse.join
    end
  end
end
