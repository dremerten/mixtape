def add(x,y)
  x + y
end

def subtract(x,y)
  x - y
end

def sum(array)
  result = 0
  array.each { |num| result += num }
  result
end

def multiply(*x)
  result = 1
  x.each { |num| result *= num }
  result
end

def power(x,y)
  n = x
  (y-1).times { n *= x }
  n
end

def factorial(x)
  if x == 0
    x = 1
  elsif x > 0
    (x-1).downto(1) { |n| x *= n }
  end
  x
end
