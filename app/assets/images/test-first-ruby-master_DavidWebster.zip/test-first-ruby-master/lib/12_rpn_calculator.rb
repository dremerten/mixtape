class RPNCalculator

ERROR = "calculator is empty"

attr_accessor :array

  def initialize
    @array = []
  end

  def push(n)
    @array << n
  end

  def plus
    if @array.size > 1
      val = @array.pop + @array.pop
      @array << val
    else
      raise ERROR
    end
  end

  def minus
    if @array.size > 1
      val = @array.pop
      new_val = @array.pop - val
      @array << new_val
    else
      raise ERROR
    end
  end

  def times
    if @array.size > 1
      val = @array.pop * @array.pop
      @array << val
    else
      raise ERROR
    end
  end

  def divide
    if @array.size > 1
      val = @array.pop
      new_val = @array.pop.to_f / val
      @array << new_val
    else
      raise ERROR
    end
  end

  def value
    @array.last
  end

  def tokens(string)

    string.split.map do |x|
      if "+-*/".include? x 
        x.to_sym
      else
        x.to_i
      end
    end

  end

  def evaluate(string)
    tokens(string).each do |x|
      if x.is_a? Integer
        push(x)
      else
        case x
          when :+ ; plus
          when :- ; minus
          when :* ; times
          when :/ ; divide
        end
      end
    end
    value
  end
end
