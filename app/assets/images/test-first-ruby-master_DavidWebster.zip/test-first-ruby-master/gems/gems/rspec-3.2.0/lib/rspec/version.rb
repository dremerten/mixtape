module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '3.2.0'
  end
end
