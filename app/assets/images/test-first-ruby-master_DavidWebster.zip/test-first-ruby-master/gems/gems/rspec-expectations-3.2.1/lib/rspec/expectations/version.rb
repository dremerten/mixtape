module RSpec
  module Expectations
    # @private
    module Version
      STRING = '3.2.1'
    end
  end
end
